=== SendContacts ===
Contributors: krishatcher87
Tags: sendgrid,recipients,contacts,sign up
Requires at least: 4.0
Tested up to: 4.5.2
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Provides simple mechanism to allow site visitors to sign up for SendGrid-powered marketing lists.

== Description ==
Description goes here

== Installation ==
installation instructions go here